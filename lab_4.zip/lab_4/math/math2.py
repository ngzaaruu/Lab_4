a = int(input("Base, first value: "))
b = int(input("Base, second value: "))
h = int(input("Height: "))

area = ((a + b)/2) * h
print(f"Area of trapezoid: {area}")
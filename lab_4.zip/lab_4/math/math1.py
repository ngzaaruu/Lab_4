import math

degree = int(input("Enter:"))
radians = degree * math.pi/180

print(radians)
a = int(input("Length of base: "))
h = int(input("Height of parallelogram: "))

area = a * h

print(f"Expected Output: {area}")